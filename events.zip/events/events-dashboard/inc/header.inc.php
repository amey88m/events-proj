<!DOCTYPE html>
<html lang="en"> 
<head>
    <title><?php echo $title; ?></title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="favicon.ico"> 
    
    <!-- FontAwesome JS-->
	<script defer src="assets/fontawesome/js/all.min.js"></script>
    
    <!-- Theme CSS -->  
    <link rel="stylesheet" href="../css/style.css" />
    <link id="theme-style" rel="stylesheet" href="assets/css/theme-1.css">
