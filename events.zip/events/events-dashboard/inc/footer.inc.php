<!-- Javascript -->          
<script src="assets/plugins/jquery-3.4.1.min.js"></script>
<script src="assets/plugins/popper.min.js"></script> 
<script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script> 
