<?php
if(!isset($_SESSION['userid12345'])) { echo "<script>window.location.href='../login.php';</script>"; }



# ---------------------- 
date_default_timezone_set('Asia/kolkata');

# variables;
$title = 'Events ';


# includes ;
include_once "inc/header.inc.php";
require "../config/config.php";

?>
</head> 
<body>
    
<?php 
   
 $result = mysqli_query($conn, "select * from tbl_events order by 5 desc");
 ?>
    
    
    <div class="main-wrapper">
	    <section class="cta-section theme-bg-light py-5">
		    <div class="container text-center">
			    <h2 class="heading">- WELCOME - </h2>
			    <div class="intro">To My Events.</div>
		    </div>
		    <div class="btn-wrapper">
		    <input type="button" class="linkStyle float-right d-block" value="download events" title="download events ">
		    <a href="../logout.php" class="linkStyle float-right d-block" title='logout'> <i class='fa fa-logout'></i>logout</a>
			</div>

	    </section>
<?php 

$today = date('Y-m-d');
$j=1;
 while($rows = mysqli_fetch_array($result)) { 

 	$day = $rows['e_date'];
 	$days = explode(' ', $day);
 	
 	# handle duration for event dt
 	$nowdt = new DateTime($today);
	$eventdt = new DateTime($days[0]);
	$interval = $nowdt->diff($eventdt);
	$published_days_indicator = '';
	$sign = substr($interval->format('%R%a days'), 0,1);

	($sign == '+') ? $published_days_indicator='remain' : $published_days_indicator='ago';

	// echo $days[0] . "->" . $today . "<br>";


	# counter 
	$counter = explode(":", $days[1]);
	$h = $counter[0];
	$m = $counter[1];
	$s = $counter[2];
	
	$time_formater = date('Y-m-d h:m:s', strtotime('now'));
	
 	?>


	    <section class="blog-list px-3 py-5 p-md-5">
		    <div class="container">
			    <div class="item mb-5">
				    <div class="media">
					     <iframe src="<?php echo $rows['e_url']; ?>" width="300" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
					   

					    <div class="media-body">
						    <h3 class="title mb-1"><a href="#"><?php echo ucfirst($rows['e_name']); ?></a></h3>

			<div class="meta mb-1"><span class="date"> <?php  echo substr($interval->format('%R%a days'), 1) . " " . $published_days_indicator?> </span>
				<span class="time">Event Date: <?php echo $days[0]; ?> </span>
				<span class="event-time-<?php echo $j; ?>"></span>
				<?php  # timer start code ----------- ?>

					<script>
					var countDownDate = <?php 
					echo strtotime("$days[0] $h:$m:$s" ) ?> * 1000;
					var now = <?php echo strtotime($time_formater);  ?> * 1000;

					var x = setInterval(function() {
					now = now + 1000;
					// Find the distance between now an the count down date
					var distance = countDownDate - now;

					// Time calculations for days, hours, minutes and seconds
					var days = Math.floor(distance / (1000 * 60 * 60 * 24));
					if(days < 10) {
						document.querySelector('.event-time-<?php echo $j;?>').classList.add('txt-danger');
					}
					var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
					var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
					var seconds = Math.floor((distance % (1000 * 60)) / 1000);
					// Output the result in an element with id="demo"
					document.querySelector(".event-time-<?php echo $j; ?>").innerHTML = 
					days + "d " + hours + "h " + minutes + "m " + seconds + "s ";

					// If the count down is over, write some text 
					if (distance < 0) {
					clearInterval(x);
					 document.querySelector(".event-time-<?php echo $j; ?>").innerHTML = "EXPIRED";
					}
						    
					}, 1000);

					</script>


				<span class="comment"><a href="#"><?php echo $day; ?></a></span>
			</div>
						    <div class="intro">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies...</div>
						    <a class="more-link" href="#">Read more &rarr;</a>
					    </div><!--//media-body-->
				    </div><!--//media-->
			    </div><!--//item-->
			</div>
	    </section>

<?php $j++; } # end of while loop ?>

		<section class="blog-list px-3 py-5 p-md-5">
		    <div class="container">
    			<nav class="blog-nav nav nav-justified my-5">
				  <a class="nav-link-prev nav-item nav-link d-none rounded-left" href="#">Previous<i class="arrow-prev fas fa-long-arrow-alt-left"></i></a>
				  <a class="nav-link-next nav-item nav-link rounded" href="#">load more<i class="arrow-next fas fa-long-arrow-alt-right"></i></a>
				</nav>
			</div>
		</section>
				
		    
	    <footer class="footer text-center py-2 theme-bg-dark">
		 
            <small class="copyright">&copy; 2020 Developed by <i class="fas fa-heart" style="color: #fb866a;"></i> <a href="http://themes.3rdwavemedia.com" target="_blank">  Amey M </a> for study purpose!!!</small>
		   
	    </footer>
    
    </div><!--//main-wrapper-->
    
    
   
       

</body>
</html> 

