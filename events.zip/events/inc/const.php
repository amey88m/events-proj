<?php 

define('key','8sfxJyxoK0k-LkoHy6tugGNbnwYaL3CqiQEXMxXSJG');

?>