<?php 
include_once "inc/const.php";


class SMS {
	

	    /*  
            SMS configuration 
        */


        # @@ api key
        public $apikey = key;


        # @@ send SMS To
        ## write multiple mobile numbers **,**...
        public $mobile      = '7517474481';



        # @@ 
        public $urlencoded  = 'TXTLCL';


        ## @@ Messages
        public $message_reg         = 'Your one time OTP Code is for activating your account is: ';
        public $message_login       = 'Your one time OTP Code to login is: ';


        ## @@ curl default url
        public $curlDefaultUrl = 'https://api.textlocal.in/send/';





}

?>