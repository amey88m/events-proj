<?php 
if(isset($_SESSION['userid12345']) ) { echo "<script>window.location.href='events-dashboard/events.php';</script>"; }

$title='User Login';
include "inc/header.inc.php"; 
include "config/config.php";

 $_return = $alert = 'false';
 $Msg_phone = $addCls ='';

	if(isset($_POST['login'])) 
	{

		# sms 
		include_once "SmsSender.php";

		# prevent sql inj
		$user_phone = mysqli_real_escape_string($conn, $_POST['phone']);


		if(empty($user_phone)){ 
			$alert = 'true';
			$Msg_phone = "phone no is empty";
			$addCls = 'invalid';
		} else {

				if(!preg_match("/^\d{10}$/", $user_phone )  || !preg_match("/^[6|7|8|9|]/", $user_phone) ) 
				{
						$alert = 'true';
						$Msg_phone = 'invalid phone no';
						$addCls = 'invalid';
				} else {

					# check given mobile no is registered or not
					$sql = "select reg_id,phone from tbl_registration where phone='".$user_phone."' ";
					
					$sql_query = mysqli_query($conn, $sql);
					$rowscount= mysqli_num_rows($sql_query);

					# check user is already registerd

					if(!empty($rowscount)){ 
						$_return = 'true';
					}else{
						$alert = 'true';
						$Msg_phone = 'not registerd yet with this phone number? click down!!';
						$addCls = 'invalid';
					}

				}

		}



		if( $_return == 'true') 
		{

			$result = mysqli_query($conn, "select reg_id,name,mail,phone from tbl_registration where phone='".$user_phone."' ");
			while($rows = mysqli_fetch_array($result)) {
				# genrate session 
				$_SESSION['user_name']  = $rows['name'];
				$_SESSION['user_email'] = $rows['mail'];
				$_SESSION['user_phone'] = $rows['phone'];
			}
			
			

			# genrate otp
			$get_otp 			= mt_rand();
			$otp 				= substr($get_otp,0,6);
			$_SESSION['otp'] 	= $otp;

			# send sms 
			$login  = new SmsSender;
			$login->smsotp($otp, "login");

			echo "<script>window.location.href='otp.php'</script>";
		}


	}
?>
</head>
<body>

<div class="container">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<form method="post" >
				<span class="form-title">Login</span>
			  

			  <div class="form-group" name="login">
			    <label for="exampleInputPhone">Phone No</label>
			    <input type="text" class="form-control <?php (!empty(strlen($Msg_phone)))? print $addCls : print ''; ?>" id="exampleInputPhone" maxlength='10' name="phone" placeholder="Enter Phone No">
			    <?php if($alert == 'true') { ?> <span class='txt-danger mt-2 d-block'><?php ($alert == 'true') ? print ucwords($Msg_phone) : ''  ?></span><?php } ?>
			  </div>

			  <br>
			  <span>Not sign up yet? click <a href="registration.php" title='registration'>here</a></span><br><br>
			  <button type="submit" class="btn btn-info btn-event" name="login" >Send OTP</button>
			</form>
		</div>
	</div>
</div>		


<?php include_once "inc/footer.inc.php"; ?>