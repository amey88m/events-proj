<?php


	# db config
	$conn = mysqli_connect('127.0.0.1','root','1234567890','17octevnts');





?>