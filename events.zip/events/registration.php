<?php  
if(isset($_SESSION['userid12345']) ) { echo "<script>window.location.href='events-dashboard/events.php';</script>"; }
$title='User Registration';
# header 
include "inc/header.inc.php"; 
date_default_timezone_set('Asia/kolkata');



$alert2 = $alert = 'false';
$hide = $Msg_phone = $Msg_email = $Msg_usr = $addCls = '';
$alert_cls = 'hide';

if(isset($_POST['registration'])){ 
		# db connection 
		require "config/config.php";

		
		# sms 
		include_once "SmsSender.php";

		# prevet from sql inj.
		$user_name = mysqli_real_escape_string($conn, $_POST['user_name']);
		$user_email = mysqli_real_escape_string($conn, $_POST['user_email']);
		$user_phone = mysqli_real_escape_string($conn, $_POST['user_phone']);

		$now = date('Y-m-d h:i:s a', strtotime('now'));

		# validation 
		if(empty($user_name)) {
			$alert = 'true';
			$Msg_usr = "user name is empty";
			$addCls = 'invalid';
		} else {

			if(!preg_match("/^[a-z0-9]{3,10}$/", $user_name) ) 
			{
					$alert = 'true';
					$Msg_usr = 'invalid user name';
					$addCls = 'invalid';
			} 
		}

		if(empty($user_email)){ 
			$alert = 'true';
			$Msg_email = "email address is empty";
			$addCls = 'invalid';
		} else {

				if(!preg_match("/^[0-9a-z]+(\d[0-9]{4})?([\.|_])?+([a-z0-9]+)?\@[a-z]{1,10}\.[a-z]{1,3}$/", $user_email) ) 
				{
						$alert = 'true';
						$Msg_email = 'invalid email address';
						$addCls = 'invalid';
				} 	
		}


		if(empty($user_phone)){ 
			$alert = 'true';
			$Msg_phone = "phone no is empty";
			$addCls = 'invalid';
		} else {

				if(!preg_match("/^\d{10}$/", $user_phone )  || !preg_match("/^[6|7|8|9|]/", $user_phone) ) 
				{
						$alert = 'true';
						$Msg_phone = 'invalid phone no';
						$addCls = 'invalid';
				}

		}




$_return = 'false';
if($alert == 'false') {
	
	# if no error found
		$sql = "select reg_id,mail,phone from tbl_registration where mail='".$user_email."' and phone='".$user_phone."' ";
		
		$sql_query = mysqli_query($conn, $sql);
		$rowscount= mysqli_num_rows($sql_query);

	# check user is already registerd

	if(empty($rowscount)){ 
		$_return = 'true';
	}else {
		$alert2  = 'true';
		$Msg2 	= "you are already registerd with this email | phone number @@ you can login using registerd phone number !!";
		$alert_cls = 'show';
	}
	

		if( $_return == 'true') 
		{

			
			# genrate session 
			$_SESSION['user_name']  = $user_name;
			$_SESSION['user_email'] = $user_email;
			$_SESSION['user_phone'] = $user_phone;

			# genrate otp
			$get_otp 			= mt_rand();
			$otp 				= substr($get_otp,0,6);
			$_SESSION['otp'] 	= $otp;

			# send sms 
			$login  = new SmsSender;
			$login->smsotp($otp, "registration");

			echo "<script>window.location.href='verify_otp.php'</script>";
		}

}



					

}


?>
</head>
<body>
<?php 

if($alert2 == 'true') { ?>
<div class="container <?php echo $alert_cls?>">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<div class="alert alert-info text-center" role="alert">
			  	<?php echo ucwords($Msg2) ?>
			</div>	
		</div>
	</div>
</div>
<?php } ?>




<div class="container">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<form method="post" name="registration" method="post">
				<span class="form-title">Registration</span>
			  <div class="form-group">
			    <label for="exampleInputusername">User Name</label>
			    <input type="text" class="form-control <?php (!empty(strlen($Msg_usr)))? print $addCls : print ''; ?>" id="exampleInputusername" name="user_name" value="<?php (isset($_POST['user_name']))? print $_POST['user_name']:'' ?>">
<?php if($alert == 'true') { ?> <span class='txt-danger'><?php ($alert == 'true') ? print ucwords($Msg_usr) : ''  ?></span><?php } ?>
			  </div>
			  
			  <div class="form-group">
			    <label for="exampleInputEmail1"> Email Address</label>
			    <input type="text" class="form-control <?php (!empty(strlen($Msg_email)))? print $addCls : print ''; ?>" id="exampleInputEmail1" name="user_email" value="<?php (isset($_POST['user_email']))? print $_POST['user_email']:'' ?>" >
<?php if($alert == 'true') { ?> <span class='txt-danger'><?php ($alert == 'true') ? print ucwords($Msg_email) : ''  ?></span><?php } ?>
			  </div>

			  <div class="form-group">
			    <label for="exampleInputPhone">Phone No</label>
			    <input type="text" maxlength='10' class="form-control <?php (!empty(strlen($Msg_phone)))? print $addCls : print ''; ?>" id="exampleInputPhone" name="user_phone" value="<?php (isset($_POST['user_phone']))? print $_POST['user_phone']:'' ?>">
<?php if($alert == 'true') { ?> <span class='txt-danger'><?php ($alert == 'true') ? print ucwords($Msg_phone) : ''  ?></span><?php } ?>
			  </div>
			  <br>
			  <span>Already sign up ? click <a href="login.php" title='login'>here</a></span><br><br>
			  <button type="submit" class="btn btn-info btn-event" name="registration">Let Me In</button>
			</form>
		</div>
	</div>
</div>		















<?php include_once "inc/footer.inc.php"; ?>