<?php 

if(!isset($_SESSION['otp']))  { echo "<script>window.location.href='registration.php';</script>"; }

$title='User Login | OTP';
include_once "inc/header.inc.php"; 

echo $_SESSION['otp'];

$alert2 = 'false';	
$Msg = $addCls = '';
$cls = 'txt-danger';
	
if(isset($_POST['login_otp'])){ 

		require "config/config.php";

		# prevent sql inj.
		$otp = mysqli_real_escape_string($conn, $_POST['otp']);

		if(empty($otp)){
				$alert2 = 'true';
				$Msg 	= "empty otp";
				$addCls = 'invalid';	
		}else {

				if($otp == $_SESSION['otp']) 
				{
					$result = mysqli_query($conn, "select reg_id from tbl_registration where phone='{$_SESSION['user_phone']}' ");
						while($rows = mysqli_fetch_array($result)) {
							$_SESSION['userid12345'] = $rows['reg_id'];
						}
					
					echo "<script>window.location.href='events-dashboard/events.php'; </script>";
				} else {
					$alert2 = 'true';
					$Msg 	= "invalid otp";
					$addCls = 'invalid';
				}	
			
		}

		

}

?>
</head>
<body>






<div class="container">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<form method="post" name="otp">
				<span class="form-title">OTP</span>
			  

			  <div class="form-group">
			    <label for="exampleInputOTP">OTP No</label>
			    <input type="text" class="form-control <?php (!empty(strlen($Msg)))? print $addCls : print ''; ?>" id="exampleInputOTP" name="otp" placeholder="Enter OTP No"  maxlength='6' >
			    <?php if($alert2 == 'true') { ?> <span class='<?php echo $cls ?>'><?php ($alert2 == 'true') ? print ucwords($Msg) : ''  ?></span><?php } ?>
			  </div>

			  <button type="submit" class="btn btn-info btn-event" name="login_otp">Login Me!</button>
			  <button type="button" class=" ml-4 btn btn-primary btn-event" name="login_otp" onclick='window.location.href="login.php" '>Back</button>
			</form>
		</div>
	</div>
</div>		

<?php include_once "inc/footer.inc.php"; ?>