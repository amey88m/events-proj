-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2020 at 05:52 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `17octevnts`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_events`
--

CREATE TABLE `tbl_events` (
  `eid` smallint(5) UNSIGNED NOT NULL,
  `e_name` varchar(100) NOT NULL,
  `e_venu` varchar(100) NOT NULL,
  `e_topic` varchar(100) DEFAULT NULL,
  `e_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `e_time` varchar(50) DEFAULT NULL,
  `e_updatedAt` date DEFAULT NULL,
  `e_email1` varchar(100) NOT NULL,
  `e_email2` varchar(100) NOT NULL,
  `e_url` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_events`
--

INSERT INTO `tbl_events` (`eid`, `e_name`, `e_venu`, `e_topic`, `e_date`, `e_time`, `e_updatedAt`, `e_email1`, `e_email2`, `e_url`) VALUES
(1, 'events and entertainments', 'mumbai', 'are you ready for your next big event', '2020-10-22 11:14:07', '10.00 am - 11.00 am', '2020-10-22', 'ameya.mapuskar@gmail.com', 'amey88_designer@yahoo.com', 'https://player.vimeo.com/video/253989945?color=ef0800&title=0&byline=0&portrait=0'),
(2, 'kalakaar events and brand management', 'mumbai', 'are you ready for Kalakaari ;)', '2020-10-21 11:05:14', '05.00 am - 05.30 am', '2020-10-21', 'ameya.mapuskar@gmail.com', 'amey88_designer@yahoo.com', 'https://player.vimeo.com/video/226053498');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_events_registration`
--

CREATE TABLE `tbl_events_registration` (
  `e_regid` smallint(5) UNSIGNED NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_mail` varchar(100) NOT NULL,
  `user_phone` varchar(12) NOT NULL,
  `registeredAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `eid` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registration`
--

CREATE TABLE `tbl_registration` (
  `reg_id` smallint(5) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `registeredAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registration_otp`
--

CREATE TABLE `tbl_registration_otp` (
  `reg_id` smallint(5) UNSIGNED DEFAULT NULL,
  `otp` int(6) NOT NULL,
  `otpsetAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_events`
--
ALTER TABLE `tbl_events`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `tbl_events_registration`
--
ALTER TABLE `tbl_events_registration`
  ADD PRIMARY KEY (`e_regid`);

--
-- Indexes for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  ADD PRIMARY KEY (`reg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_events`
--
ALTER TABLE `tbl_events`
  MODIFY `eid` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_events_registration`
--
ALTER TABLE `tbl_events_registration`
  MODIFY `e_regid` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_registration`
--
ALTER TABLE `tbl_registration`
  MODIFY `reg_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
