<?php 
if(isset($_SESSION['userid12345']) ) { echo "<script>window.location.href='events-dashboard/events.php';</script>"; }
if(!isset($_SESSION['otp']))  { echo "<script>window.location.href='registration.php';</script>"; }

$title='User Registration | verify otp';

include_once "inc/header.inc.php"; 
?>


</head>
<body>


<?php 
echo $_SESSION['otp'] ; 
$alert2 = 'false';	
$Msg = $addCls = '';
$cls = 'txt-danger';
$now = date('Y-m-d h:i:s a', strtotime('now'));
	
	if( isset($_POST['register_otp'] ) ) {

		require "config/config.php";
		
		# prevent sql inj.
		$otp = mysqli_real_escape_string($conn, $_POST['otp']);
		$type = mysqli_real_escape_string($conn, $_POST['otptype']);
		$otp = trim($otp);
		
			# restict userr
			if( strtolower($type) == 'sms' || ucfirst($type) == 'Sms' || $type == "SMS" ) {

					
					# verify otp
					if( !preg_match("/^\d{6}/", $otp) ) {
						$alert2 = 'true';
						$Msg = "invalid otp!!";
						$addCls = 'invalid';
					} else {

						if($otp == $_SESSION['otp']) 
						{
							
							# allow user to registerd
							$sql = "INSERT INTO tbl_registration(name,mail,phone,registeredAt) values('{$_SESSION['user_name']}','{$_SESSION['user_email']}','{$_SESSION['user_phone']}','$now')";
							mysqli_query($conn, $sql);
							$result = mysqli_query($conn, "select reg_id from tbl_registration where mail='{$_SESSION['user_email']}' ");
							
							while($rows = mysqli_fetch_array($result)) {
								$_SESSION['userid12345'] = $rows['reg_id'];
							}
							
							
							
							echo "<script>window.location.href='events-dashboard/events.php'; </script>";
						} else {
							$alert2 = 'true';
							$Msg 	= "invalid otp";
							$addCls = 'invalid';
						}	
					}
					

			} else {
				http_response_code(404); die;
			}
		
	}

?>


<div class="container">
	<div class="row">
		<div class="col-md-6 offset-md-3">
			<form method="post" name="register_otp">
				<span class="form-title">OTP Verification </span>

				<div class="form-group text-center">
					<input type="radio" class=" mb-2" id="exampleInputradio" checked name='otptype' value="sms"><br>
			    	<label for="exampleInputradio">SMS</label>
			  	</div>


			  <div class="form-group">
			    <label for="exampleInputotp">Enter Your OTP</label>
			    <input type="text" class="form-control  <?php (!empty(strlen($Msg)))? print $addCls : print ''; ?>" id="exampleInputotp" placeholder="OTP" maxlength='6' name='otp'>
			    <?php if($alert2 == 'true') { ?> <span class='<?php echo $cls ?>'><?php ($alert2 == 'true') ? print ucwords($Msg) : ''  ?></span><?php } ?>
			  </div>
			  

			  <button type="submit" class="btn btn-info btn-event" name="register_otp">Register Me</button>
			  <button type='button' class="btn btn-dark btn-event" onclick='window.location.href="registration.php" '>Back Me </button>
			</form>
		</div>
	</div>
</div>		



<?php include_once "inc/footer.inc.php"; ?>