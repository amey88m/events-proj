
<?php

include_once "Sms.php";

class SmsSender extends SMS{

        private $otpcodegenerate;
        private $msg;
        private $body;
        private $mailId;
        public $email_notify;

    
        public function smsotp($otpcodegenerate, $code) {
                


                if($code == 'registration') {
                        $this->msg  = $this->message_reg;
                }else if($code == 'login') {    
                        $this->msg  = $this->message_login;
                }
                $this->otpcodegenerate = $otpcodegenerate;
                $apiKey = urlencode($this->apikey);
                $numbers = array($this->mobile);
                $sender = urlencode($this->urlencoded);
                $message = rawurlencode($this->msg .' ' .$this->otpcodegenerate.'');
                $numbers = implode(',', $numbers);
        
                // Prepare data for POST request
                $data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
        
                // Send the POST request with cURL
                $ch = curl_init($this->curlDefaultUrl);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                curl_close($ch);
                

        }

}


?>